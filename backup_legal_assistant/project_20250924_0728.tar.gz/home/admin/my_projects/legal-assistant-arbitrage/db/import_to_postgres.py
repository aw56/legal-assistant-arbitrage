# Script to import JSON into PostgreSQL
